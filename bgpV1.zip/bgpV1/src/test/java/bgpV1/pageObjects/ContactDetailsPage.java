package bgpV1.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactDetailsPage {

	WebDriver wdriver;
	
	public ContactDetailsPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
		
	}	
	
	@FindBy(xpath="//*[@id='react-contact_info-name']")
	WebElement txtName;
	
	@FindBy(xpath="//*[@id='react-contact_info-designation']")
	WebElement txtJobTitle;
	
	@FindBy(xpath="//*[@id='react-contact_info-phone']")
	WebElement txtContactNo;
	
	@FindBy(xpath="//*[@id='react-contact_info-primary_email']")
	WebElement txtEmail;	
	
	@FindBy(xpath="(//*[@class='bgp-checkbox'])[1]")
	WebElement chxSameAsRegistered;	
	
	@FindBy(xpath="//*[@id='react-contact_info-offeree_name']")
	WebElement txtAddresseeName;	
	
	@FindBy(xpath="//*[@id='react-contact_info-offeree_designation']")
	WebElement txtAddresseeJob;
	
	@FindBy(xpath="//*[@id='react-contact_info-offeree_email']")
	WebElement txtAddresseeEmail;
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;

	public void setName(String MainName) {
		txtName.sendKeys(MainName);		
	}
	
	public void setMainJobTitle(String MainJobTitle) {
		txtJobTitle.sendKeys(MainJobTitle);
	}
	
	public void setMainPhoneNo(String MainPhoneNo) {
		txtContactNo.sendKeys(MainPhoneNo);
	}
	
	public void setMainEmail(String MainEmail) {
		txtEmail.sendKeys(MainEmail);
	}
	
	public void setAddresseeName(String AddresseeName) {
		txtAddresseeName.sendKeys(AddresseeName);
	}
	
	public void setAddresseeJobTitle(String AddresseeJobTitle) {
		txtAddresseeJob.sendKeys(AddresseeJobTitle);
	}
	
	public void setAddresseeEmail(String AddresseeEmail) {
		txtAddresseeEmail.sendKeys(AddresseeEmail);
	}
	
	public void clickSameAsRegistered() {
		chxSameAsRegistered.click();
	}
	
	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
	}
	
	
	
	
	
	
	
}