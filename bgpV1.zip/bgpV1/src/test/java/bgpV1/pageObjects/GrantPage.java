package bgpV1.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GrantPage {

WebDriver wdriver;
	
	public GrantPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}
	
	@FindBy(xpath="(//*[@class='dashboard-action-title'])[1]")
	WebElement lnkEditCompanyProfile;	
	
	@FindBy(xpath="//*[contains(text(),'My Grants')]")
	WebElement lnkMyGrant;	
	
	@FindBy(xpath="//*[@href='#processing']")
	WebElement lnkProcessing;
	
	@FindBy(xpath="//*[@id='logout-button']")
	WebElement btnLogout;

	@FindBy(xpath="(//*[@class='dashboard-action-title'])[2]")
	WebElement lnkGetNewGrant;
	
	@FindBy(xpath="(//*[@class='dashboard-action-title'])[3]")
	WebElement lnkLearnToApply;
	
	@FindBy(xpath="//div[contains(text(),'Agriculture')]")
	WebElement lnkAgriculture;
	
	@FindBy(xpath="//div[contains(text(),'Building & Construction')]")
	WebElement lnkBuildingAndConstr;
	
	@FindBy(xpath="//div[contains(text(),'IT')]")
	WebElement lnkIT;
	
	@FindBy(xpath="//div[contains(text(),'Financial Services')]")
	WebElement lnkFinancialServices;
	
	@FindBy(xpath="//div[contains(text(),'Upgrade key business')]")
	WebElement lnkUpgradeKeyBusiness;
	
	@FindBy(xpath="//div[contains(text(),'Bring my business')]")
	WebElement lnkBringMyBusiness;
	
	@FindBy(xpath="//div[contains(text(),'Market Readiness Assistance')]")
	WebElement lnkMarketReadinessAssistance;
	
	@FindBy(xpath="//div[contains(text(),'Productivity Solutions Grant')]")
	WebElement lnkProductivitySolutionsGrant;
	
	@FindBy(xpath="//div[contains(text(),'//div[contains(text(),'Core Capabilities')]")
	WebElement lnkCoreCapabilities;
	
	@FindBy(xpath="//div[contains(text(),'//div[contains(text(),'Innovation & Productivity')]")
	WebElement lnkInnovationProductivity;
	
	@FindBy(xpath="//button[@id='go-to-grant']")
	WebElement btnApply;
	
	@FindBy(xpath="//*[@id='keyPage-form-button']")
	WebElement btnProceed;
		
	public void clickProceed() {
		btnProceed.click();
	}	
	
	public void clickMyGrant() {
		lnkMyGrant.click();
	}	
	
	public void clickProcessing() {
		lnkProcessing.click();
	}
	
	public void clickLogout() {
		btnLogout.click();
	}
	
	public Boolean checkRefIDPresent(String givenRefID) {
		try {
			WebElement ele = wdriver.findElement(By.xpath("//*[contains(text(),'"+givenRefID+"')]"));		
			if(ele.isDisplayed()) {
				return true;				
			}else return false;
		}catch(Exception e) {
			return false;
		}
	}
	
	public void clickMarketReadinessAssistance() {
		lnkMarketReadinessAssistance.click();
	}

	
	public void clickProductivitySolutionsGrant() {
		lnkProductivitySolutionsGrant.click();
	}

	public void clickCoreCapabilities() {
		lnkCoreCapabilities.click();
	}
	
	public void clickInnovationProductivity() {
		lnkInnovationProductivity.click();
	}

	
	public void clickApply() {
		btnApply.click();
	}
	
	public void clickUpgradeKeyBusiness() {
		lnkUpgradeKeyBusiness.click();
	}
	
	public void clickBringMyBusiness() {
		lnkBringMyBusiness.click();
	}
	
	public void clickAgriculture() {
		lnkAgriculture.click();
	}
	
	public void clickBuildingAndConstr() {
		lnkBuildingAndConstr.click();
	}
	
	public void clickIT() {
		lnkIT.click();
	}
	
	public void clickFinancialServices() {
		lnkFinancialServices.click();
	}
	
	
	public void clickEditCompanyProfile() {
		lnkEditCompanyProfile.click();
	}
	
	
	public void clickGetNewGrant() {
		lnkGetNewGrant.click();
	}
	
	public void clickLearnToApply() {
		lnkLearnToApply.click();
	}
	
					
}
