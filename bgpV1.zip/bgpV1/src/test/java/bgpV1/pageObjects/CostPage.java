package bgpV1.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CostPage {
	
	WebDriver wdriver;
	
	public CostPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}	

	@FindBy(xpath="(//*[@class='accordion-chevron pull-right'])[3]")
	WebElement txtSalary;
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-name']")
	WebElement txtName;
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-designation']")
	WebElement txtDesignation;
	
	@FindBy(xpath="//*[@class='Select-control']")
	WebElement drpDownNationalityType;
	
	
	
	@FindBy(xpath="(//*[@class='form-control bgp-textarea'])[1]")
	WebElement txtProjectRole;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-right-addon']")
	WebElement txtProjectInvolve;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-left-addon bgp-currency-input']")
	WebElement txtMonthlySalary;
	
	@FindBy(xpath="(//*[@class='bgp-btn bgp-btn-fullwidth'])[1]")
	WebElement btnAddNewItem;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[1]")
	WebElement rSingaporeVendor;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[2]")
	WebElement rOverseasVendor;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield']")
	WebElement txtVendorName;	
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-left-addon bgp-currency-input']")
	WebElement txtEstimateCost;	
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;
	
	public void setProjectInvolve(String givenProjInv) {
		txtProjectInvolve.sendKeys(givenProjInv);
	}

	public void setProjectRole(String givenProjRole) {
		txtProjectRole.sendKeys(givenProjRole);
	}
	
	public void setNationalityType(String drpDownNationalityTypeValue) {
		Select dropdown2 = new Select(drpDownNationalityType);  
		dropdown2.selectByValue(drpDownNationalityTypeValue); 		
	}
	
	public void setDesignation(String givenDesc) {
		txtDesignation.sendKeys(givenDesc);
	}
	
	public void setName(String givenName) {
		txtName.sendKeys(givenName);
	}
	
	public void setSalary(String givenSal) {
		txtSalary.sendKeys(givenSal);
	}
	
	public void setMonthlySalary(String monthlySal) {
		txtMonthlySalary.sendKeys(monthlySal);
	}

	public void clickAddNewItem() {
		btnAddNewItem.click();
	}
	
	public void clickSingaporeVendor() {
		rSingaporeVendor.click();
	}	
	
	public void clickOverseasVendor() {
		rOverseasVendor.click();
	}
	
	public void setVendorName(String vName) {
		txtVendorName.sendKeys(vName);
	}	
		
	public void setEstimateCose(String estCost) {
		txtEstimateCost.sendKeys(estCost);
	}
	
	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
	}
	
}
