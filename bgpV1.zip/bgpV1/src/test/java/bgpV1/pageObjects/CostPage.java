package bgpV1.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CostPage {
	
	WebDriver wdriver;
	
	public CostPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}	

	@FindBy(xpath="(//*[@class='accordion-chevron pull-right'])[3]")
	WebElement btnSalary;
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-name']")
	WebElement txtName;
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-designation']")
	WebElement txtDesignation;
	
	@FindBy(xpath="//*[@class='Select-control']")
	WebElement drpDownNationalityType;	
	
	@FindBy(xpath="(//*[@class='form-control bgp-textarea'])[1]")
	WebElement txtProjectRole;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-right-addon']")
	WebElement txtProjectInvolve;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-left-addon bgp-currency-input']")
	WebElement txtMonthlySalary;
	
	//@FindBy(xpath="(//*[@class='bgp-btn bgp-btn-fullwidth'])[3]")
	//@FindBy(xpath="(//*[contains(text(),'Add New Item')])[3]")	
	@FindBy(xpath="(//*[@id='react-project_cost-salaries'])[2]")
	WebElement btnAddNewItem;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[1]")
	WebElement rSingaporeVendor;
	
	@FindBy(xpath="(//*[@class='radiobutton'])[2]")
	WebElement rOverseasVendor;
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield']")
	WebElement txtVendorName;	
	
	@FindBy(xpath="//*[@class='form-control bgp-textfield  bgp-has-left-addon bgp-currency-input']")
	WebElement txtEstimateCost;	
	
	@FindBy(xpath="//*[@id='react-project_cost-salaries-0-attachments-btn']")
	WebElement fileDragAndDropFile;
	
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;
	
	public void setProjectInvolve(String givenProjInv) {
		txtProjectInvolve.sendKeys(givenProjInv);
	}

	public void setProjectRole(String givenProjRole) {
		txtProjectRole.sendKeys(givenProjRole);
	}
	
	public void setfileDragAndDropFile(String givenFileName) {
		fileDragAndDropFile.sendKeys(givenFileName);	
	}
	
	public void setNationalityType(String drpDownNationalityTypeValue) throws InterruptedException {
		drpDownNationalityType.click();
		WebElement ele = wdriver.findElement(By.xpath("//*[contains(text(),'"+drpDownNationalityTypeValue+"')]"));
		ele.click();		
		Thread.sleep(1000); 
 		
	}
	
	public void setDesignation(String givenDesc) {
		txtDesignation.sendKeys(givenDesc);
	}
	
	public void setName(String givenName) {
		txtName.sendKeys(givenName);
	}
	
	public void clickSalary() {
		btnSalary.click();
	}

	public void clickAddNewItem() {
		btnAddNewItem.click();
	}
	
	public void setMonthlySalary(String monthlySal) {
		txtMonthlySalary.sendKeys(monthlySal);
	}
	
	public void clickSingaporeVendor() {
		rSingaporeVendor.click();
	}	
	
	public void clickOverseasVendor() {
		rOverseasVendor.click();
	}
	
	public void setVendorName(String vName) {
		txtVendorName.sendKeys(vName);
	}	
		
	public void setEstimateCost(String estCost) {
		txtEstimateCost.sendKeys(estCost);
	}
	
	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
	}
	
}
