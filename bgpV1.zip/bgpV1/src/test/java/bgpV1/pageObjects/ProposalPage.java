package bgpV1.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ProposalPage {

WebDriver wdriver;
	
	public ProposalPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}
	
	@FindBy(xpath="//*[@id='react-project-title']")
	WebElement txtProjectTitle;	
	
	public void setProjectTitle(String projTitle) {
		txtProjectTitle.sendKeys(projTitle);		
	}
	
	@FindBy(xpath="//*[@id='react-project-start_date']")
	WebElement txtStartDate;	
	
	@FindBy(xpath="//*[@id='react-project-end_date']")
	WebElement txtEndDate;
	
	@FindBy(xpath="//*[@id='react-project-description']")
	WebElement txtProjectDesc;
	
	@FindBy(xpath="(//*[@class='Select-arrow-zone'])[1]")
	WebElement drpDownActivity;
	
	@FindBy(xpath="(//*[@class='Select-arrow-zone'])[2]")
	WebElement drpDownTargetMarket;
	
	@FindBy(xpath="(//*[@name='react-project-is_first_time_expand'])[1]")
	WebElement radioFirstTimeExpandYes;
	
	@FindBy(xpath="(//*[@name='react-project-is_first_time_expand'])[2]")
	WebElement radioFirstTimeExpandNo;
	
	@FindBy(xpath="//*[@id='react-project-attachments-btn']")
	WebElement fileDragAndDropFile;
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;
	
	public void setStartDate(String projStartDate) {
		txtStartDate.sendKeys(projStartDate);		
	}
	
	public void setEndDate(String projEndDate) {
		txtEndDate.sendKeys(projEndDate);		
	}
	
	public void setDownActivity(String givenActivity) throws InterruptedException {
		drpDownActivity.click();
		WebElement ele = wdriver.findElement(By.xpath("//*[contains(text(),'"+givenActivity+"')]"));
		ele.click();
		Thread.sleep(1000); 		
	}
	
	public void setDownTargetMarket(String givenMarket) throws InterruptedException {
		drpDownTargetMarket.click();
		WebElement ele = wdriver.findElement(By.xpath("//*[contains(text(),'"+givenMarket+"')]"));
		ele.click();		
		Thread.sleep(1000); 		
	}
	
	public void setFirstTimeExpandYes() {
		radioFirstTimeExpandYes.click();	
	}
	
	public void uploadDoc() {
		fileDragAndDropFile.click();	
	}
	
	public void setFirstTimeExpandNo() {
		radioFirstTimeExpandNo.click();	
	}
	
	public void setfileDragAndDropFile(String givenFileName) {
		fileDragAndDropFile.sendKeys(givenFileName);	
	}
	
	public void setProjectDesc(String projDesc) throws InterruptedException {
		txtProjectDesc.sendKeys(projDesc);		
		Thread.sleep(1000);
	}
	
	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
	}


}
