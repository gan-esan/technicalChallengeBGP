package bgpV1.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BusinessImpactPage {
	
	WebDriver wdriver;
	
	public BusinessImpactPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
		
	}	

	@FindBy(xpath="//*[@id='react-project_impact-fy_end_date_0']")
	WebElement txtFYEndDate;	
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[1]")
	WebElement txtOverseasSales1;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[2]")
	WebElement txtOverseasSales2;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[3]")
	WebElement txtOverseasSales3;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[4]")
	WebElement txtOverseasSales4;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[5]")
	WebElement txtOverseasInvestments1;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[6]")
	WebElement txtOverseasInvestments2;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[7]")
	WebElement txtOverseasInvestments3;
	
	@FindBy(xpath="(//*[@class='form-control bgp-textfield '])[8]")
	WebElement txtOverseasInvestments4;
	
	@FindBy(xpath="//*[@id='react-project_impact-rationale_remarks']")
	WebElement txtRationaleProjection;
	
	@FindBy(xpath="//*[@id='react-project_impact-benefits_remarks']")
	WebElement txtNonTangibleBenefits;	
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;
	
	public void setRationaleProjection(String RationaleProjectionValue) {
		txtRationaleProjection.sendKeys(RationaleProjectionValue);
	}
	
	public void setNonTangibleBenefits(String NonTangibleBenefitsValue) {
		txtNonTangibleBenefits.sendKeys(NonTangibleBenefitsValue);
	}
	
	public void setFYEndDate(String FYEndDateValue) {
		txtFYEndDate.sendKeys(FYEndDateValue);
	}
	
	public void setOverseasSales1(String OverseasSales1) {
		txtOverseasSales1.sendKeys(OverseasSales1);
	}
	
	public void setOverseasSales2(String OverseasSales2) {
		txtOverseasSales2.sendKeys(OverseasSales2);
	}
	
	public void setOverseasSales3(String OverseasSales3) {
		txtOverseasSales3.sendKeys(OverseasSales3);
	}
	
	public void setOverseasSales4(String OverseasSales4) {
		txtOverseasSales4.sendKeys(OverseasSales4);
	}
	
	public void setOverseasInvestments1(String OverseasInvestments1) {
		txtOverseasInvestments1.sendKeys(OverseasInvestments1);
	}
	
	public void setOverseasInvestments2(String OverseasInvestments2) {
		txtOverseasInvestments2.sendKeys(OverseasInvestments2);
	}
	
	public void setOverseasInvestments3(String OverseasInvestments3) {
		txtOverseasInvestments3.sendKeys(OverseasInvestments3);
	}
	
	public void setOverseasInvestments4(String OverseasInvestments4) {
		txtOverseasInvestments4.sendKeys(OverseasInvestments4);
	}

	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
	}
	
}
