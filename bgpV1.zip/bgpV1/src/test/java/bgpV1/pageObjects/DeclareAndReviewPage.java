package bgpV1.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DeclareAndReviewPage {
	
	WebDriver wdriver;
	
	public DeclareAndReviewPage(WebDriver gdriver) {
		
		wdriver=gdriver;
		PageFactory.initElements(gdriver, this);		
	}		

	@FindBy(xpath="(//*[@class='bgp-radio'])[1]")
	WebElement rDeclare1No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[2]")
	WebElement rDeclare1Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[3]")
	WebElement rDeclare2No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[4]")
	WebElement rDeclare2Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[5]")
	WebElement rDeclare3No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[6]")
	WebElement rDeclare3Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[7]")
	WebElement rDeclare4No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[8]")
	WebElement rDeclare4Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[9]")
	WebElement rDeclare5No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[10]")
	WebElement rDeclare5Yes;
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[11]")
	WebElement rDeclare6No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[12]")
	WebElement rDeclare6Yes;
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[13]")
	WebElement rDeclare7No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[14]")
	WebElement rDeclare7Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[15]")
	WebElement rDeclare8No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[16]")
	WebElement rDeclare8Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[17]")
	WebElement rDeclare9No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[18]")
	WebElement rDeclare9Yes;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[19]")
	WebElement rDeclare10No;	
	
	@FindBy(xpath="(//*[@class='bgp-radio'])[20]")
	WebElement rDeclare10Yes;	
	
	@FindBy(xpath="//*[@id='back-btn']")
	WebElement btnPrevious;
	
	@FindBy(xpath="//*[@id='save-btn']")
	WebElement btnSave;
	
	@FindBy(xpath="//*[@id='next-btn']")
	WebElement btnNext;
		
	public void clickPrevious() {
		btnPrevious.click();
	}
	
	public void clickSave() {
		btnSave.click();
	}
	
	public void clickNext() {
		btnNext.click();
	}
	
	public void clickrDeclare1No() {
		rDeclare1No.click();
	}
	
	public void clickrDeclare1Yes() {
		rDeclare1Yes.click();
	}
	
	public void clickrDeclare2No() {
		rDeclare2No.click();
	}
	
	public void clickrDeclare2Yes() {
		rDeclare2Yes.click();
	}
	
	public void clickrDeclare3No() {
		rDeclare3No.click();
	}
	
	public void clickrDeclare3Yes() {
		rDeclare3Yes.click();
	}
	
	public void clickrDeclare4No() {
		rDeclare4No.click();
	}
	
	public void clickrDeclare4Yes() {
		rDeclare4Yes.click();
	}

	public void clickrDeclare5No() {
		rDeclare5No.click();
	}
	
	public void clickrDeclare5Yes() {
		rDeclare5Yes.click();
	}
	
	public void clickrDeclare6No() {
		rDeclare6No.click();
	}
	
	public void clickrDeclare6Yes() {
		rDeclare6Yes.click();
	}
	
	public void clickrDeclare7No() {
		rDeclare7No.click();
	}
	
	public void clickrDeclare7Yes() {
		rDeclare7Yes.click();
	}
	
	public void clickrDeclare8No() {
		rDeclare8No.click();
	}
	
	public void clickrDeclare8Yes() {
		rDeclare8Yes.click();
	}
	
	public void clickrDeclare9No() {
		rDeclare9No.click();
	}
	
	public void clickrDeclare9Yes() {
		rDeclare9Yes.click();
	}
	
	public void clickrDeclare10No() {
		rDeclare10No.click();
	}
	
	public void clickrDeclare10Yes() {
		rDeclare10Yes.click();
	}
	
}
