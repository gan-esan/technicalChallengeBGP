package bgpV1.testCases;

import org.apache.logging.log4j.core.config.Loggers;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import bgpV1.pageObjects.GrantPage;
import bgpV1.pageObjects.PublicLoginPage;
import bgpV1.pageObjects.EligibilityPage;
import bgpV1.pageObjects.ContactDetailsPage;
import bgpV1.pageObjects.ProposalPage;
import bgpV1.pageObjects.BusinessImpactPage;

public class TC1_LoginTest extends BaseClass{

	@Test
	public void loginTest() throws InterruptedException{
	   driver.get(givenURL);
	   Logger.info("Open BGP Public Portal");
	   PublicLoginPage lgnPage = new PublicLoginPage(driver);
	   GrantPage grntPage = new GrantPage(driver);
	   driver.manage().window().maximize();
	   Thread.sleep(1000);	 
	   
	   driver.findElement(By.xpath("(//input[@id='signInFormUsername'])[2]")).clear();
	   driver.findElement(By.xpath("(//input[@id='signInFormUsername'])[2]")).sendKeys("public");
	   Logger.info("Key-in Public UserName");
	   driver.findElement(By.xpath("(//input[@id='signInFormPassword'])[2]")).clear();
	   driver.findElement(By.xpath("(//input[@id='signInFormPassword'])[2]")).sendKeys("Let$BeC001");
	   Logger.info("Key-in Public Password");
		 
		 //driver.findElement(By.xpath("(//*[@name='signInSubmitButton'])[2]")).click();
		 
	   //lgnPage.setUserName(givenUserName);
	   //lgnPage.setPassword(givenPassword);
	   lgnPage.clickSubmit();
	   Logger.info("Successfully login as Public");
	   Thread.sleep(1000);
	   lgnPage.clickLogIn();
	   Logger.info("Click LOG IN Button");
	   Thread.sleep(1000);
	   Logger.info("Key-in required EntityID, NRI, Role, FullName");
	   lgnPage.setEntityID(givenEntityID);
	   lgnPage.setUserNRIC(givenNRIC);
	   lgnPage.setUserRole(givenUserRole);
	   lgnPage.setUserFullName(givenFullName);	   
	   lgnPage.clickSubmit2();
	   Logger.info("Successfully click Login Button");
	   Thread.sleep(10000);
	   
	   Logger.info("Inside Grant Page");
	   Logger.info("Click Get New Grant");
	   grntPage.clickGetNewGrant();
	   Thread.sleep(1000);
	   Logger.info("Click IT");
	   grntPage.clickIT();
	   Thread.sleep(2000);
	   Logger.info("Select Bring my business overseas");
	   grntPage.clickBringMyBusiness();
	   Thread.sleep(2000);
	   Logger.info("Select Market Readiness Assistance");
	   grntPage.clickMarketReadinessAssistance();
	   Thread.sleep(3000);
	   Logger.info("Click Apply");
	   try {
		   grntPage.clickApply();
		   //driver.findElement(By.xpath("//button[@id='go-to-grant']")).click();
	   }catch(Exception e) {
		   Logger.info("Apply button error"+e.toString());
	   }	   
	   Thread.sleep(3000);
	   Logger.info("Click Proceed");
	   grntPage.clickProceed();
	   
	   Logger.info("Adding Eligibility Details");
	   EligibilityPage eligiblilityPage = new EligibilityPage(driver);
	   Thread.sleep(3000);
	   
		 eligiblilityPage.clickEligibilityTurnOverYes();
		 eligiblilityPage.clickLocalEquityYes();
		 eligiblilityPage.clickNewMarketCheckYes();
		 eligiblilityPage.clickAllStatementTrueYes();
		 
	   eligiblilityPage.clickSave();
	   Thread.sleep(1000);
	   eligiblilityPage.clickNext();
	   Thread.sleep(3000);
	   Logger.info("Adding Contact Details");
	   ContactDetailsPage contactPage = new ContactDetailsPage(driver);
	   contactPage.setName(MainName);
	   contactPage.setMainJobTitle(MainJobTitle);
	   contactPage.setMainPhoneNo(MainPhoneNo);
	   contactPage.setMainEmail(MainEmail);
	   contactPage.clickSameAsRegistered();
	   contactPage.setAddresseeName(AddresseeName);
	   contactPage.setAddresseeJobTitle(AddresseeJobTitle);
	   contactPage.setAddresseeEmail(AddresseeEmail);
	   contactPage.clickSave();
	   Thread.sleep(1000);
	   contactPage.clickNext();
	   Thread.sleep(5000);
	   
	   ProposalPage propPage = new ProposalPage(driver);
	   propPage.setProjectTitle("ProjectTitle");
	   propPage.setStartDate("19 Jul 2022");
	   propPage.setEndDate("12 Oct 2022");
	   propPage.setProjectDesc("Given Project Description");
	   propPage.setDownActivity("FTA consultancy");
	   propPage.setDownTargetMarket("Afghanistan");
	   propPage.setFirstTimeExpandYes();
	   propPage.setfileDragAndDropFile("C:\\testDoc\\SupportingDoc.docx");
	   propPage.clickSave();
	   Thread.sleep(1000);
	   contactPage.clickNext();
	   Thread.sleep(5000);
	   
	   
	   BusinessImpactPage bussImpPage = new BusinessImpactPage(driver);
	   bussImpPage.setFYEndDate("12 Jan 2021");
	   bussImpPage.setOverseasSales1("123");
	   bussImpPage.setOverseasSales2("123");
	   bussImpPage.setOverseasSales3("123");
	   bussImpPage.setOverseasSales4("123");
	   bussImpPage.setOverseasInvestments1("111");
	   bussImpPage.setOverseasInvestments2("111");
	   bussImpPage.setOverseasInvestments3("111");
	   bussImpPage.setOverseasInvestments4("111");
	   bussImpPage.setRationaleProjection("Testing Testing");
	   bussImpPage.setNonTangibleBenefits("Testing Testing");
	   propPage.clickSave();
	   Thread.sleep(1000);
	   contactPage.clickNext();
	   Thread.sleep(5000);
	   
	}
}
